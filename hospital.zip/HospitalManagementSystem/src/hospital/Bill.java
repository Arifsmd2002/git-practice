package hospital;

public class Bill {

    private double consultationFee = 500;
    private double medicineFee = 300;

    public void generateBill() {

        double total = consultationFee + medicineFee;

        System.out.println("\n----- Bill Details -----");
        System.out.println("Consultation Fee: " + consultationFee);
        System.out.println("Medicine Fee: " + medicineFee);
        System.out.println("Total Bill: " + total);
    }
}
