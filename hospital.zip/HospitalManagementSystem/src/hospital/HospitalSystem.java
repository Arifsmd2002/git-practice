package hospital;

import java.util.Scanner;

public class HospitalSystem {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Add Patient
        System.out.print("Enter Patient ID: ");
        int pid = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Patient Name: ");
        String pname = sc.nextLine();

        System.out.print("Enter Patient Age: ");
        int age = sc.nextInt();

        Patient patient = new Patient(pid, pname, age);

        // Assign Doctor
        System.out.print("\nEnter Doctor ID: ");
        int did = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Doctor Name: ");
        String dname = sc.nextLine();

        System.out.print("Enter Specialization: ");
        String spec = sc.nextLine();

        Doctor doctor = new Doctor(did, dname, spec);

        // Create Appointment
        Appointment appointment = new Appointment(patient, doctor);

        // Generate Bill
        Bill bill = new Bill();

        // Display Records
        appointment.display();
        bill.generateBill();

        sc.close();
    }
}
