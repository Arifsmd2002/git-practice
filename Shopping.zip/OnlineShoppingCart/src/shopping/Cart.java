package shopping;

import java.util.ArrayList;

public class Cart {

    private ArrayList<Product> products = new ArrayList<>();

    public void addProduct(Product product) {
        products.add(product);
        System.out.println("Product added to cart.");
    }

    public void removeProduct(int productId) {

        boolean removed = false;

        for (Product p : products) {
            if (p.getProductId() == productId) {
                products.remove(p);
                removed = true;
                System.out.println("Product removed.");
                break;
            }
        }

        if (!removed) {
            System.out.println("Product not found.");
        }
    }

    public double calculateTotal() {

        double total = 0;

        for (Product p : products) {
            total += p.getPrice();
        }

        return total;
    }

    public void displayCart() {

        System.out.println("\n--- Cart Items ---");

        if (products.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }

        for (Product p : products) {
            p.display();
        }
    }
}
