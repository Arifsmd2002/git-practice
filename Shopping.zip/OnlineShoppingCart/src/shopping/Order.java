package shopping;

public class Order {

    private double discountPercentage = 10;  // 10% discount

    public double applyDiscount(double total) {

        double discount = total * (discountPercentage / 100);
        return total - discount;
    }
}
