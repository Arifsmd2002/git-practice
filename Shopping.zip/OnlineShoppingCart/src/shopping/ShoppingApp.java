package shopping;

import java.util.Scanner;

public class ShoppingApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Cart cart = new Cart();
        Order order = new Order();

        while (true) {

            System.out.println("\n--- Online Shopping Cart ---");
            System.out.println("1. Add Product");
            System.out.println("2. Remove Product");
            System.out.println("3. View Cart");
            System.out.println("4. Calculate Total");
            System.out.println("5. Apply Discount & Checkout");
            System.out.println("6. Exit");
            System.out.print("Choose option: ");

            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter Product ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Product Name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter Price: ");
                    double price = sc.nextDouble();

                    Product product = new Product(id, name, price);
                    cart.addProduct(product);
                    break;

                case 2:
                    System.out.print("Enter Product ID to remove: ");
                    int removeId = sc.nextInt();
                    cart.removeProduct(removeId);
                    break;

                case 3:
                    cart.displayCart();
                    break;

                case 4:
                    double total = cart.calculateTotal();
                    System.out.println("Total Amount: ₹" + total);
                    break;

                case 5:
                    double totalAmount = cart.calculateTotal();
                    double finalAmount = order.applyDiscount(totalAmount);
                    System.out.println("Total before discount: ₹" + totalAmount);
                    System.out.println("Final after 10% discount: ₹" + finalAmount);
                    break;

                case 6:
                    System.out.println("Thank you for shopping!");
                    sc.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
